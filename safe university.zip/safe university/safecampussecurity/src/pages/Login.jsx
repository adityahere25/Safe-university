import React from 'react';
import LoginStudent from '../components/Login/Login'

const Login = () => {
  return (
    <div>
        <LoginStudent />
    </div>
  )
}

export default Login