import React from 'react';
import LoginAdmin from '../components/Login/Login'

const Login = () => {
  return (
    <div>
        <LoginAdmin />
    </div>
  )
}

export default Login